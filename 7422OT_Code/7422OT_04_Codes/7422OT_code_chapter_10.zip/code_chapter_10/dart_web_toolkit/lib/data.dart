//Copyright (C) 2012 Sergey Akopkokhyants. All Rights Reserved.
//Author: akserg

/**
 * Dart Web Toolkit Data library.
 */
library dart_web_toolkit_data;

part 'src/data/provides_key.dart';
part 'src/data/simple_key_provider.dart';
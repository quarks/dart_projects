//Copyright (C) 2012 Sergey Akopkokhyants. All Rights Reserved.
//Author: akserg

library dart_web_toolkit_core;

part 'src/core/impl.dart';
part 'src/core/dwt.dart';

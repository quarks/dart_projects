//Copyright (C) 2012 Sergey Akopkokhyants. All Rights Reserved.
//Author: akserg

part of dart_web_toolkit_event;

/**
 * Interface for objects that have a direction estimator.
 */
abstract class HasDirectionEstimator {

//  /**
//   * Returns the {@code DirectionEstimator} object.
//   */
//  DirectionEstimator getDirectionEstimator();
//
//  /**
//   * Toggles on / off direction estimation.
//   *
//   * @param enabled Whether to enable direction estimation. If {@code true},
//   *          sets the {@link DirectionEstimator} object to a default
//   *          {@code DirectionEstimator}.
//   */
//  void enableDefaultDirectionEstimator(bool enabled);
//
//  /**
//   * Sets the {@link DirectionEstimator} object.
//   *
//   * @param directionEstimator The {@code DirectionEstimator} to be set. {@code
//   *        null} means turning off direction estimation.
//   */
//  void setDirectionEstimator(DirectionEstimator directionEstimator);
}

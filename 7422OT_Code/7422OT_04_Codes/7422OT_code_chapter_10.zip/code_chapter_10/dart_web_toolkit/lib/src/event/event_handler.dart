//Copyright (C) 2012 Sergey Akopkokhyants. All Rights Reserved.
//Author: akserg

part of dart_web_toolkit_event;

/**
 * Marker interface for event handlers. All stock GWT Widget and dom event
 * handlers extend [EventHandler].
 */
abstract class EventHandler {

}

part of effects;

class _Enum {
  final String name;

  const _Enum(this.name);

  String toString() => name;
}

import 'dart:html';
import 'package:bootjack/bootjack.dart';

void main() {
  Scrollspy.use();
}

